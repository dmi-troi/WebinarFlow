$ErrorActionPreference = 'Stop'
$OverlayPath = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "1/7. Проверяю PowerShell/Node/npm..." -ForegroundColor Cyan
node --version
npm --version

$RepoPath = Read-Host "Укажи путь к твоей папке WebinarFlow, например C:\WebinarFlow"
$RepoPath = $RepoPath.Trim().Trim('"')
if (-not (Test-Path (Join-Path $RepoPath 'package.json'))) {
  throw "В папке не найден package.json: $RepoPath"
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path (Split-Path -Parent $RepoPath) ("WebinarFlow-backup-" + $stamp)
New-Item -ItemType Directory -Path $backup -Force | Out-Null

Write-Host ""
Write-Host "2/7. Делаю резервную копию изменяемых файлов: $backup" -ForegroundColor Cyan
$items = @('src','prisma/schema.prisma','package.json','next.config.ts','entrypoint.sh','.env.example')
foreach ($item in $items) {
  $src = Join-Path $RepoPath $item
  if (Test-Path $src) {
    $dst = Join-Path $backup $item
    $parent = Split-Path -Parent $dst
    if ($parent -and -not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    Copy-Item $src $dst -Recurse -Force
  }
}

Write-Host ""
Write-Host "3/7. Накладываю подготовленное обновление..." -ForegroundColor Cyan
foreach ($item in $items) {
  $source = Join-Path $OverlayPath $item
  $destination = Join-Path $RepoPath $item
  if (-not (Test-Path $source)) { continue }
  $parent = Split-Path -Parent $destination
  if ($parent -and -not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
  Copy-Item $source $destination -Recurse -Force
  Write-Host "  OK $item" -ForegroundColor Green
}

Set-Location $RepoPath

Write-Host ""
Write-Host "4/7. Устанавливаю зависимости и исправленную версию Next.js..." -ForegroundColor Cyan
npm install
npm install next@16.3.6 eslint-config-next@16.3.6

Write-Host ""
Write-Host "5/7. Проверяю Prisma и TypeScript..." -ForegroundColor Cyan
npx prisma validate
npx tsc --noEmit

Write-Host ""
Write-Host "6/7. Проверяю production build..." -ForegroundColor Cyan
npm run build

Write-Host ""
Write-Host "7/7. Итог" -ForegroundColor Cyan
Write-Host "Локальное обновление и production build завершены успешно." -ForegroundColor Green
Write-Host "Резервная копия: $backup" -ForegroundColor Green
Write-Host "GitHub не изменён." -ForegroundColor Green
Write-Host ""
Write-Host "Следующий шаг после проверки: deploy на Render и обновить webhook/cron." -ForegroundColor Yellow
