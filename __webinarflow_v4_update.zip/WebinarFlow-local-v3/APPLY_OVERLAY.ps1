param(
  [Parameter(Mandatory=$false)]
  [string]$RepoPath
)

$ErrorActionPreference = 'Stop'
$OverlayPath = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not $RepoPath) {
  $RepoPath = Read-Host 'Укажи полный путь к папке WebinarFlow (например C:\WebinarFlow)'
}

if (-not (Test-Path (Join-Path $RepoPath 'package.json'))) {
  throw "В указанной папке не найден package.json: $RepoPath"
}

$items = @(
  'src',
  'prisma/schema.prisma',
  'package.json',
  'next.config.ts',
  'entrypoint.sh',
  '.env.example'
)

foreach ($item in $items) {
  $source = Join-Path $OverlayPath $item
  $destination = Join-Path $RepoPath $item
  if (-not (Test-Path $source)) { continue }
  $parent = Split-Path -Parent $destination
  if ($parent -and -not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
  Copy-Item -Path $source -Destination $destination -Recurse -Force
  Write-Host "Скопировано: $item" -ForegroundColor Green
}

Write-Host ''
Write-Host 'Готово. GitHub НЕ изменён.' -ForegroundColor Cyan
Write-Host 'Следующий шаг: открыть папку проекта и выполнить DEPLOYMENT_BEGINNER.md по пунктам.' -ForegroundColor Cyan
