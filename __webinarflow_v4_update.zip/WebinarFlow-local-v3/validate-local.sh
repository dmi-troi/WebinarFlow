#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

pass=0
fail=0
check() {
  local name="$1"; shift
  if "$@" >/dev/null 2>&1; then echo "PASS: $name"; pass=$((pass+1)); else echo "FAIL: $name"; fail=$((fail+1)); fi
}

check "TypeScript (stubbed, strict with noImplicitAny=false like repo)" tsc -p validation-stubs/tsconfig.json --pretty false
check "entrypoint shell syntax" sh -n entrypoint.sh
check "package.json syntax" node -e "JSON.parse(require('fs').readFileSync('package.json','utf8'))"
check "Prisma schema has additive archive MTS fields" grep -q 'mtsLinkWebinarId' prisma/schema.prisma
check "No destructive db push flag in code/config" bash -c 'files=$(find . -type f ! -path "./validation-stubs/*" ! -name "*.md" ! -name "*.ps1" ! -name "validate-local.sh"); test -z "$(grep -n -- "--accept-data-loss" $files 2>/dev/null || true)"'
check "MTS route has no write HTTP methods" bash -c '! grep -E --line-number "method:[[:space:]]*['"'"'\"'"'"'](POST|PUT|PATCH|DELETE)['"'"'\"'"'"']" src/app/api/mts-link/route.ts'
check "Settings does not expose API token values" bash -c '! grep -E --line-number "map\\[[^]]*(telegramBotToken|mtsLinkApiKey)|map\\.?(telegramBotToken|mtsLinkApiKey)[[:space:]]*=" src/app/api/settings/route.ts'
check "All protected API routes use withAuth/requireAuth" bash -c '
  bad=0
  for f in src/app/api/*/route.ts src/app/api/*/*/route.ts; do
    [ -f "$f" ] || continue
    case "$f" in
      src/app/api/auth/route.ts|src/app/api/health/route.ts|src/app/api/notifications/cron/route.ts|src/app/api/telegram/webhook/route.ts) continue;;
    esac
    grep -Eq "withAuth|requireAuth" "$f" || { echo "unprotected: $f" >&2; bad=1; }
  done
  test "$bad" -eq 0
'
check "No user-supplied GitHub token pattern in project" bash -c '! grep -R -n -E "ghp_[A-Za-z0-9]{20,}" --exclude-dir=.git .'
check "Telegram webhook validates secret header" grep -q 'x-telegram-bot-api-secret-token' src/app/api/telegram/webhook/route.ts
check "Cron validates Authorization secret" grep -q 'authorization' src/app/api/notifications/cron/route.ts
check "Business-day planner used by task generation" grep -q 'shiftToBusinessDay' src/app/api/webinars/generate-tasks/route.ts
check "Business-day planner used on webinar date change" grep -q 'shiftToBusinessDay' src/app/api/webinars/route.ts
check "MSK date handling in Telegram messages" grep -q 'mskStartOfToday' src/lib/telegram/messages.ts
check "MSK date handling in Dashboard" grep -q 'formatInTimeZone' src/components/webinarflow/DashboardPage.tsx
check "MTS UI explicitly read-only" grep -q 'Только чтение' src/components/webinarflow/SettingsPage.tsx
check "Logo setting present" grep -q 'brandingLogo' src/app/api/settings/route.ts

printf '\nTOTAL: %d PASS, %d FAIL\n' "$pass" "$fail"
test "$fail" -eq 0
