$ErrorActionPreference = 'Stop'
Write-Host 'Обновление Next.js до исправленной Active LTS версии...' -ForegroundColor Cyan
npm install next@16.3.6 eslint-config-next@16.3.6
Write-Host ''
Write-Host 'Готово. Теперь обязательно выполните:' -ForegroundColor Green
Write-Host '  npx prisma validate'
Write-Host '  npx tsc --noEmit'
Write-Host '  npm run build'
