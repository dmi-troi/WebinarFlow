declare namespace React { type ElementType = any; type FormEvent = any; type ChangeEvent<T=any> = any; type Key = string | number; interface Attributes { key?: Key | null } interface CSSProperties { [key: string]: any } }
declare namespace JSX { interface IntrinsicAttributes extends React.Attributes {} interface IntrinsicElements { [elemName: string]: any } }
declare module 'react' { export function useState<T>(v:T):[T,(x:T|((p:T)=>T))=>void]; export function useEffect(fn:any,deps?:any[]):void; export function useCallback<T extends (...a:any[])=>any>(fn:T,deps?:any[]):T; export function useMemo<T>(fn:()=>T,deps:any[]):T; export type FormEvent=React.FormEvent; export type ChangeEvent<T=any>=React.ChangeEvent<T>; export type CSSProperties=React.CSSProperties; }
declare module 'next/server' { export class NextRequest extends Request { nextUrl:any; cookies:any; } export class NextResponse extends Response { static json(body?:any, init?:any):NextResponse; static next(init?:any):NextResponse; cookies:any; } }
declare module '@prisma/client' { export type PrismaClient = any; export namespace Prisma { export type PrismaPromise<T=unknown> = Promise<T> & { then:any; catch:any; finally:any } } }
declare module 'node:crypto' { export const createHash:any; export const randomBytes:any; export const scryptSync:any; export const timingSafeEqual:any; }
declare module 'date-fns' { export const format:any; export const isToday:any; export const isTomorrow:any; export const addDays:any; export const addMonths:any; export const addWeeks:any; export const endOfMonth:any; export const endOfWeek:any; export const startOfMonth:any; export const startOfWeek:any; export const subMonths:any; export const subWeeks:any; }
declare module 'date-fns/locale' { export const ru:any; }
declare module 'date-fns-tz' { export const fromZonedTime:any; export const formatInTimeZone:any; }
declare module 'lucide-react' { export const AlertTriangle:any; export const ArrowRight:any; export const CalendarDays:any; export const CheckCircle2:any; export const Clock3:any; export const ExternalLink:any; export const Film:any; export const ListTodo:any; export const RefreshCw:any; export const ShieldAlert:any; export const Users:any; export const Video:any; export const LayoutDashboard:any; export const CheckSquare:any; export const Archive:any; export const Settings:any; export const ChevronLeft:any; export const ChevronRight:any; export const PanelLeftClose:any; export const ChevronUp:any; export const LogIn:any; export const Save:any; export const Send:any; export const AlertCircle:any; export const Zap:any; export const Link2:any; export const Upload:any; export const Trash2:any; export const Image:any; export const ShieldCheck:any; export const Clock:any; export const Copy:any; export const KeyRound:any; export const RotateCcw:any; export const List:any; export const Columns3:any; export const CalendarClock:any; export const CircleAlert:any; export const ClipboardList:any; export const GripVertical:any; export const Pencil:any; export const Plus:any; export const Search:any; export const UserRound:any; export const Download:any; export const ListChecks:any; export const Sparkles:any; }
declare module 'sonner' { export const toast:any; }
declare module '@/lib/store' { export const useAppStore:any; }
declare module '@/lib/types' { export interface Webinar{[k:string]:any}; export interface Task{[k:string]:any}; export interface Responsible{[k:string]:any}; export interface DashboardStats{[k:string]:any}; export interface CalendarEvent{[k:string]:any} }
declare module '@/components/ui/card' { export const Card:any; export const CardContent:any; export const CardHeader:any; export const CardTitle:any; export const CardDescription:any; }
declare module '@/components/ui/button' { export const Button:any; }
declare module '@/components/ui/input' { export const Input:any; }
declare module '@/components/ui/label' { export const Label:any; }
declare module '@/components/ui/switch' { export const Switch:any; }
declare module '@/components/ui/radio-group' { export const RadioGroup:any; export const RadioGroupItem:any; }
declare module '@/components/ui/badge' { export const Badge:any; }
declare module '@/components/ui/scroll-area' { export const ScrollArea:any; }
declare module '@/components/ui/sonner' { export const Toaster:any; }
declare module '@/components/ui/tabs' { export const Tabs:any; export const TabsList:any; export const TabsTrigger:any; export const TabsContent:any; }
declare module '@/components/ui/dialog' { export const Dialog:any; export const DialogContent:any; export const DialogHeader:any; export const DialogTitle:any; export const DialogDescription:any; export const DialogFooter:any; }
declare module '@/components/ui/alert-dialog' { export const AlertDialog:any; export const AlertDialogAction:any; export const AlertDialogCancel:any; export const AlertDialogContent:any; export const AlertDialogDescription:any; export const AlertDialogFooter:any; export const AlertDialogHeader:any; export const AlertDialogTitle:any; }
declare module '@/components/ui/select' { export const Select:any; export const SelectContent:any; export const SelectItem:any; export const SelectTrigger:any; export const SelectValue:any; }
declare module '@/components/webinarflow/WebinarsPage' { export const WebinarsPage:any; }
declare module '@/components/webinarflow/TasksPage' { export const TasksPage:any; }
declare module '@/components/webinarflow/CalendarPage' { export const CalendarPage:any; }
declare module '@/components/webinarflow/ArchivePage' { export const ArchivePage:any; }
declare module '@/components/webinarflow/ResponsiblesPage' { export const ResponsiblesPage:any; }
declare module '@/components/webinarflow/SettingsPage' { export const SettingsPage:any; }
declare module '@/lib/db' { export const db:any; }
declare module '@/lib/msk-time' { export const MSK_TZ:any; export const mskInputToDate:any; export const formatMsk:any; export const mskDateInputValue:any; export const mskTimeInputValue:any; }
declare module '@/lib/auth' { export const hashPassword:any; export const isHashedPassword:any; export const verifyPassword:any; export const createSession:any; export const setSessionCookie:any; export const clearSessionCookie:any; export const verifyRequest:any; export const requireAuth:any; export const withAuth:any; export const SESSION_COOKIE:any; }
declare var process: any; declare var Buffer: any;
declare module '@/lib/telegram/messages' { export const msgSummary:any; export const msgPersonalTasks:any; export const msgHelp:any; export const msgToday:any; export const msgTasks:any; export const msgUpcoming:any; }
declare module './BrandLogo' { export const BrandLogo:any; export const notifyBrandLogoUpdated:any; }

declare module '@/components/ui/textarea' { export const Textarea:any; }
