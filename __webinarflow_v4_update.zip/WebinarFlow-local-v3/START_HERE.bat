@echo off
setlocal
cd /d "%~dp0"

echo.
echo ================================================
echo WebinarFlow - safe local update
echo ================================================
echo.
echo This script does NOT push anything to GitHub.
echo It will backup changed files, apply the update,
echo update Next.js, validate Prisma/TypeScript,
echo and run the production build.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_HERE.ps1"
if errorlevel 1 (
  echo.
  echo UPDATE/BUILD FINISHED WITH ERRORS.
  echo Read the message above and send it to ChatGPT if needed.
  pause
  exit /b 1
)

echo.
echo ================================================
echo ALL LOCAL CHECKS PASSED
echo ================================================
echo.
echo GitHub was NOT changed.
pause
exit /b 0
