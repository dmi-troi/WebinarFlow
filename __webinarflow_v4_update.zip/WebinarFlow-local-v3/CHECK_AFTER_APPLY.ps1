$ErrorActionPreference = 'Stop'

Write-Host '=== WebinarFlow local checks ===' -ForegroundColor Cyan
Write-Host ''

node -v
npm -v
Write-Host ''

Write-Host '[1/4] Prisma validate' -ForegroundColor Yellow
npx prisma validate
Write-Host ''

Write-Host '[2/4] TypeScript' -ForegroundColor Yellow
npx tsc --noEmit
Write-Host ''

Write-Host '[3/4] Build' -ForegroundColor Yellow
npm run build
Write-Host ''

Write-Host '[4/4] Dangerous commands scan' -ForegroundColor Yellow
$danger = Get-ChildItem -Recurse -File -Include *.ts,*.tsx,*.js,*.mjs,*.cjs,*.json,*.sh,*.yml,*.yaml,Dockerfile,*.tsconfig -Exclude node_modules,.next | Select-String -SimpleMatch '--accept-data-loss' -ErrorAction SilentlyContinue
if ($danger) {
  Write-Error 'Найдена опасная команда --accept-data-loss. Проверь проект перед деплоем.'
}

Write-Host ''
Write-Host 'Все локальные проверки закончились без ошибок.' -ForegroundColor Green
